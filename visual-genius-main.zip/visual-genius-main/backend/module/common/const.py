from typing import Final

FILE_UPLOAD: Final[str] = "file_upload"
HTTP_IDENTIFIER: Final[str] = "http"
