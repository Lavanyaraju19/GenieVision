
export const pathes = {
    gen: '/gen',
    rtn: '/rtn',
    home: '/home'
}