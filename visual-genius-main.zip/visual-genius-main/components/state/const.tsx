export const API_ENDPOINT = process.env.NEXT_PUBLIC_ENV_TYPE == 'dev'? process.env.NEXT_PUBLIC_API_ENDPOINT: ''
export const MS_CLARITY_ID = process.env.NEXT_PUBLIC_MS_CLARITY_ID
export const UPLOAD_CATEGORY_ID = 'file_upload'
export const FALLBACK_SRC = 'none.png'